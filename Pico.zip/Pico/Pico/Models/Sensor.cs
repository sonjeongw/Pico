﻿using Pico.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Pico.Models
{
    public class Sensor
    {
        [Key]
        public int SensorNo { get; set; }
  
        [Required(ErrorMessage = "제목을 입력하세요.")]
        public string SensorColor { get; set; }

        [Required(ErrorMessage = "내용을 입력하세요.")]
        public DateTime SensorDate { get; set; } 
    }
}