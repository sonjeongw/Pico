﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Pico.Models
{
    public class User
    {
        [Key]
        public int UserNo { get; set; }

        [Required(ErrorMessage = "사용자 ID를 입력하세요.")]
        public string UserID { get; set; }

        [Required(ErrorMessage = "사용자 비밀번호를 입력하세요.")]
        public string UserPW { get; set; }

        [Required(ErrorMessage = "사용자 이름을 입력하세요.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "사용자 출생일자를 입력하세요.")]
        public DateTime UserAge { get; set; }

        [Required]
        public DateTime UserDate { get; set; } = DateTime.Now;
    }
}