﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Pico.Models
{
    public class Order
    {
        [Key]
        public int OrderNo { get; set; }

        [Required(ErrorMessage = "색상을 입력하세요")]
        public string OrderColor { get; set; }

        [Required]
        public DateTime OrderDate { get; set; } = DateTime.Now; // 현재 날짜와 시간으로 초기화

    }
}
