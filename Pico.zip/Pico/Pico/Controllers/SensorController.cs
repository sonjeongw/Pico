﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pico.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Pico.Controllers
{
    public class SensorController : Controller
    {
        public class SensorOrderViewModel
        {
            public List<Sensor> Sensors { get; set; }
            public List<Order> Orders { get; set; }
        }
        
        //리스트 출력
        // GET: /<controller>/
        public IActionResult Index()
        {
            if(HttpContext.Session.GetString("USER_LOGIN_KEY") == null)
            {
                return RedirectToAction("Login", "Account");
            }
            using (var db = new PicoDbContext())
            {
                var viewModel = new SensorOrderViewModel
                {
                    Sensors = db.Sensors.ToList(),
                    Orders = db.Orders.ToList()
                };

                return View(viewModel);
            }
        }

        public IActionResult Order()
        {
            if (HttpContext.Session.GetString("USER_LOGIN_KEY") == null)
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Order(Order model)
        {
            if (HttpContext.Session.GetString("USER_LOGIN_KEY") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                using (var db = new PicoDbContext())
                {
                    db.Orders.Add(model);
                    if(db.SaveChanges() > 0)
                    {
                        return Redirect("Index");
                    }
                }
                ModelState.AddModelError(string.Empty, "Order을 요청할수 없습니다.");
            }
            return View(model);
        }

        public IActionResult Sensor_Log(string sensorColor, DateTime? sensorDate)
        {
            if (HttpContext.Session.GetString("USER_LOGIN_KEY") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            using (var db = new PicoDbContext())
            {
                // 초기에는 모든 센서를 가져옴
                IQueryable<Sensor> sensorsQuery = db.Sensors;

                // 선택한 색상이 있는 경우 해당 색상으로 필터를 적용
                if (!string.IsNullOrEmpty(sensorColor))
                {
                    sensorsQuery = sensorsQuery.Where(s => s.SensorColor == sensorColor);
                }

                // 선택한 날짜가 있는 경우 해당 날짜로 필터를 적용
                if (sensorDate.HasValue)
                {
                    sensorsQuery = sensorsQuery.Where(s => s.SensorDate.Date == sensorDate.Value.Date);
                }

                // 쿼리를 리스트로 변환
                var viewModel = new SensorOrderViewModel
                {
                    Sensors = sensorsQuery.ToList(),
                    Orders = db.Orders.ToList()
                };

                return View(viewModel);
            }
        }


        public IActionResult Order_Log(string orderColor, DateTime? orderDate)
        {
            if (HttpContext.Session.GetString("USER_LOGIN_KEY") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            using (var db = new PicoDbContext())
            {
                // 초기에는 모든 주문을 가져옴
                IQueryable<Order> ordersQuery = db.Orders;

                // 선택한 오더 색상이 있는 경우 해당 색상으로 필터 적용
                if (!string.IsNullOrEmpty(orderColor))
                {
                    ordersQuery = ordersQuery.Where(o => o.OrderColor == orderColor);
                }

                // 선택한 오더 날짜가 있는 경우 해당 날짜로 필터 적용
                if (orderDate.HasValue)
                {
                    ordersQuery = ordersQuery.Where(o => o.OrderDate.Date == orderDate.Value.Date);
                }

                // 쿼리를 리스트로 변환
                var viewModel = new SensorOrderViewModel
                {
                    Sensors = db.Sensors.ToList(),
                    Orders = ordersQuery.ToList()
                };

                return View(viewModel);
            }
        }
    }
}