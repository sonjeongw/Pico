﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pico.Models;
using Pico.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pico.Controllers
{
    public class AccountController : Controller
    {
        // GET: /<controller>/
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                using (var db = new PicoDbContext())
                {
                    var user = db.Users
                        .FirstOrDefault(u => u.UserID.Equals(model.UserID) &&
                        u.UserPW.Equals(model.UserPW));
                    if (user == null)
                    {
                        // 로그인에 실패했을때
                        // 사용자 ID 자체가 회원가입 x 경우
                        ModelState.AddModelError(string.Empty, "사용자 ID 혹은 비밀번호가 올바르지 않습니다.");
                    }
                    else
                    {
                        // 로그인에 성공했을 때
                        // HttpContext.Session.SetInt32(key, value);
                        HttpContext.Session.SetString("USER_LOGIN_KEY", user.UserID);
                        return RedirectToAction("Index", "Sensor");
                    }
                }
            }
            return View(model);
        }


        public IActionResult Logout()
        {
            HttpContext.Session.Remove("USER_LOGIN_KEY");
            return RedirectToAction("Index", "Home");
        }



        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User model)
        {
            if (ModelState.IsValid)
            {
                using (var db = new PicoDbContext())
                {
                    db.Users.Add(model);
                    db.SaveChanges();
                }
                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }
    }

}
